// get form elements
const form = document.getElementById("clearance-form");
const firstName = document.getElementById("first-name");
const lastName = document.getElementById("last-name");
const email = document.getElementById("email");
const program = document.getElementById("program");
const finance = document.getElementById("finance");
const library = document.getElementById("library");
const sports = document.getElementById("sports");

form.addEventListener("submit", (event) => {
  event.preventDefault(); 
  
  if (validateForm()) {
    showSuccessMessage();
  
  }
});


function validateForm() {
  let valid = true;
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;


  if (firstName.value === "") {
    setErrorFor(firstName, "First name cannot be blank");
    valid = false;
  } else {
    setSuccessFor(firstName);
  }


  if (lastName.value === "") {
    setErrorFor(lastName, "Last name cannot be blank");
    valid = false;
  } else {
    setSuccessFor(lastName);
  }

  if (email.value === "") {
    setErrorFor(email, "Email cannot be blank");
    valid = false;
  } else if (!emailRegex.test(email.value)) {
    setErrorFor(email, "Invalid email format");
    valid = false;
  } else {
    setSuccessFor(email);
  }

 
  if (program.value === "") {
    setErrorFor(program, "Please select your program");
    valid = false;
  } else {
    setSuccessFor(program);
  }

  // validate finance clearance
  if (!finance.checked) {
    setErrorFor(finance, "You must complete finance clearance");
    valid = false;
  } else {
    setSuccessFor(finance);
  }

  // validate library clearance
  if (!library.checked) {
    setErrorFor(library, "You must complete library clearance");
    valid = false;
  } else {
    setSuccessFor(library);
  }

  // validate sports clearance
  if (!sports.checked) {
    setErrorFor(sports, "You must complete sports clearance");
    valid = false;
  } else {
    setSuccessFor(sports);
  }

  return valid;
}

// set input field to error state
function setErrorFor(input, message) {
  const formGroup = input.parentElement;
  const error = formGroup.querySelector(".error");
  input.classList.add("error");
  error.innerText = message;
}

// set input field to success state
function setSuccessFor(input) {
  const formGroup = input.parentElement;
  input.classList.remove("error");
}

// show success message after form submission
function showSuccessMessage() {
  const successMessage = document.createElement("div");
  successMessage.classList.add("success");
  successMessage.innerText = "You have been cleared for graduation!";
  form.insertBefore(successMessage, form.childNodes[0]);
}
function checkClearance() {
    // Get the form data
    const form = document.getElementById('clearance-form');
    const finance = form.elements['finance'].checked;
    const library = form.elements['library'].checked;
    const department1 = form.elements['department1'].checked;
    const department2 = form.elements['department2'].checked;
    const program1 = form.elements['program1'].checked;
    const program2 = form.elements['program2'].checked;
  
    // Check if all requirements are met
    if (finance && library && department1 && department2 && program1 && program2) {
      document.getElementById('result').innerHTML = 'Congratulations! You are cleared to graduate.';
    } else {
      document.getElementById('result').innerHTML = 'Sorry, you are not cleared to graduate.';
    }
  }
  



  const form = document.getElementById("myForm");
const output = document.getElementById("output");

form.addEventListener("submit", function(event) {
  event.preventDefault();
  const input1Value = form.elements.input1.value;
  const input2Value = form.elements.input2.value;

  if (input1Value && input2Value) {
    // Clear the form and show the output
    form.reset();
    output.innerText = `Input 1: ${input1Value}\nInput 2: ${input2Value}`;
  } else {
    // Show an error message
    output.innerText = "Please fill in both inputs.";
  }
}


// Get the sign up link and the sign up form
const loginForm = document.querySelector('.login-box form');
const signupLink = document.getElementById('signup-link');
const signupBox = document.querySelector('.signup-box');

signupLink.addEventListener('click', function() {
	loginForm.classList.add('hidden');
	signupBox.classList.remove('hidden');
});

const signupForm = document.querySelector('.signup-box form');
signupForm.addEventListener('submit', function(e) {
	e.preventDefault();
	const name = signupForm.querySelector('input[name="name"]').value;
	const email = signupForm.querySelector('input[name="email"]').value;
	const password = signupForm.querySelector('input[name="password"]').value;
	const confirmPassword = signupForm.querySelector('input[name="confirm-password"]').value;
	if (password !== confirmPassword) {
		alert('Passwords do not match. Please try again.');
	} else {
		alert(`Thank you for signing up, ${name}!`);
		signupForm.reset();
	}
});





);
