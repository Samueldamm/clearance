<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // collect input data from form and sanitize
    $name = filter_input(INPUT_POST, "name", FILTER_SANITIZE_STRING);
    $idNumber = filter_input(INPUT_POST, "id-number", FILTER_SANITIZE_STRING);
    $program = filter_input(INPUT_POST, "program", FILTER_SANITIZE_STRING);
    $department = filter_input(INPUT_POST, "department", FILTER_SANITIZE_STRING);
    $email = filter_input(INPUT_POST, "email", FILTER_SANITIZE_EMAIL);
    $contact = filter_input(INPUT_POST, "contact", FILTER_SANITIZE_STRING);
    $requirements = filter_input(INPUT_POST, "requirements", FILTER_SANITIZE_STRING, FILTER_REQUIRE_ARRAY);

    // display output
    echo "<h1>Clearance Form Submitted:</h1>";
    echo "<p>Name: $name</p>";
    echo "<p>Admission number: $idNumber</p>";
    echo "<p>Program: $program</p>";
    echo "<p>Department: $department</p>";
    echo "<p>Email: $email</p>";
    echo "<p>Contact Number: $contact</p>";
    echo "<p>Clearance Requirements:</p>";
    echo "<ul>";
    foreach ($requirements as $requirement) {
        echo "<li>$requirement</li>";
    }
    echo "</ul>"

$errors = [];

if ($_SERVER["REQUEST_METHOD"] == "POST") {

  if (empty($_POST['name'])) {
    $errors['name'] = 'Please enter your name';
  }
 
  if (empty($errors)) {
   
    $response = ['status' => 'success', 'message' => 'Your form has been successfully submitted'];
    echo json_encode($response);
    exit;
  }
  
  else {
    $response = ['status' => 'error', 'errors' => $errors];
    echo json_encode($response);
    exit;
  }
}
}

?>